#!/bin/bash

set -e

#--------------------------------------------
# goal: build core from Spack stack
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ
#         version 2019.03.18
#--------------------------------------------
  
python_ver=python3.7

script_dir=$(dirname "$0")

module purge

source $script_dir/../1-setup-spack.sh
source $script_dir/../2-setup-compiler.sh

spack_compiler=$(echo $spack_compiler | sed -e "s/@/-/")

echo Proteus-stack location: $SPACK_ROOT
echo Proteus-stack compiler: $spack_compiler

#--------------------------------------------
# 3. write 1-setup-core.sh
#--------------------------------------------

cat > 1-setup-core.sh << EOF
#!/bin/bash

source $SPACK_ROOT/1-setup-spack.sh
source $SPACK_ROOT/2-setup-compiler.sh

#export PYTHONPATH=$SPACK_ROOT/lib/spack
#export PYTHONPATH=$(spack location -i python)/bin:\$PYTHONPATH
#export PYTHONPATH=$install_dir:\$PYTHONPATH
#export PYTHONPATH=$(pwd)/python/bin:\$PYTHONPATH

echo Running $(pwd)/1-setup-core.sh
echo Loading lots of modules...

$(spack module tcl loads | grep -v \# | grep $spack_compiler)
$(spack module tcl loads | grep -v \# | grep binutils)

#export PATH=$(pwd)/python/bin:\$PATH

EOF

chmod +x  1-setup-core.sh

#--------------------------------------------
# 8. print final user info
#--------------------------------------------

echo ------------------------------------------
echo
echo To compile codes using the stack software:
echo
echo source $(pwd)/1-setup-core.sh
echo
echo compile your code
echo

