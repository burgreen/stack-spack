#!/bin/bash

#set -x
#set -e

#--------------------------------------------
# purpose: prepare the directory for pkg installations
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ, July 2018
#--------------------------------------------

if [ -z "$SPACK_ROOT" ]; then 
  source ./1-setup-spack.sh
fi

err=1

#--------------------------------------------
# 1. avail compiler
#--------------------------------------------

if [ "$1" == "avail" ]; then
echo ----------------------------------------------------------------
spack compilers
echo ----------------------------------------------------------------
echo Any of the compilers above this line be used to build a package.
echo 
echo If you desire to add another system compiler to this list: 
echo 
echo 1. Set new \<compiler\> up via: \"module load ...\", \"swsetup ...\", etc. for your system.
echo 2. Then run: $0 add \<compiler\>
    err=0
fi

#--------------------------------------------
# 2. add compiler
#--------------------------------------------

if [ "$1" == "add" ]; then
if [[ ! -z "$2" ]]; then
echo adding compiler: $2
echo ----------------------------------------------------------------
spack compiler find
echo 
spack compilers
echo ----------------------------------------------------------------
echo Any of the compilers above this line be used to build a package.
echo 
echo If you desire to add another system compiler to this list: 
echo 
echo 1. Set new \<compiler\> up via: \"module load ...\", \"swsetup ...\", etc. for your system.
echo 2. Then run: $0 add \<compiler\>
err=0
fi
if [[ -z "$2" ]]; then
echo ----------------------------------------------------------------
spack compiler find
echo 
spack compilers
echo ----------------------------------------------------------------
echo Any of the compilers above this line be used to build a package.
echo 
echo If you desire to add another system compiler to this list: 
echo 
echo 1. Set new \<compiler\> up via: \"module load ...\", \"swsetup ...\", etc. for your system.
echo 2. Then run: $0 add \<compiler\>
err=0
fi
fi

#--------------------------------------------
# 2. try compiler
#--------------------------------------------

if [ "$1" == "try" ]; then
if [[ ! -z "$2" ]]; then
echo trying compiler: $2
spack install libelf %$2
echo ----------------------------------------------------------------
spack compilers
echo ----------------------------------------------------------------
echo If last line below reads: ==\> 1 installed packages:
echo 
echo   - Congratulations, you are done with this stage of the installation.
echo   - Finalize this compiler via ./scripts/compiler.sh use $2
echo 
echo If last line below reads: ==\> 0 installed packages:
echo 
echo   - Try another Available compiler, or
echo   - setup another system compiler via ./scripts/compiler.sh instructions.
echo ----------------------------------------------------------------
spack find 
echo
err=0
fi
fi

#--------------------------------------------
# 3. use compiler
#--------------------------------------------

if [ "$1" == "use" ]; then
if [[ ! -z "$2" ]]; then

echo using compiler: $2

compiler=$2

cat > 2-setup-compiler.sh << EOF
#!/bin/bash

module use $SPACK_ROOT/share/spack/modules/$(spack arch)

spack_compiler=$compiler
    
unset F90
export FC=$(spack compiler info $compiler | grep fc | cut -f 3 | cut -f 3 -d " ")
EOF

cp 2-setup-compiler.sh 3-sys-compiler.txt

err=0

fi
fi

if [ "$err" -eq 1 ]; then 
  echo 
  echo ----------------------------------------------------------------
  echo Usage:
  echo 
  echo $0 \<directive\> \<compiler\>
  echo 
  echo where \<directive\> = avail, add, try, or use
  echo 
  echo For example: 
  echo $0 avail
  echo $0 add gcc@5.1.0
  echo $0 try gcc@5.1.0
  echo $0 use gcc@5.1.0
  exit
fi

#set +e
#set +x
