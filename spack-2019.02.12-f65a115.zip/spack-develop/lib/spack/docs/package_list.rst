.. Copyright 2013-2019 Lawrence Livermore National Security, LLC and other
   Spack Project Developers. See the top-level COPYRIGHT file for details.

   SPDX-License-Identifier: (Apache-2.0 OR MIT)

.. _package-list:

============
Package List
============

This is a list of things you can install using Spack.  It is
automatically generated based on the packages in the latest Spack
release.

.. raw:: html
   :file: package_list.html
